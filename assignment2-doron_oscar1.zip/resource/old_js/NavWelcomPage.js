$(document).ready(function(){
	$('#mainWindow').children().hide()
	$('#nav').show()
	$('#logo').show()
    $('#welcome').show()
    $('#footer').show()

    $('#welcomPage').click(function(){
        $('#mainWindow').children().hide()
        $('#nav').show()
        $('#logo').show()
        $('#welcome').show()
        $('#footer').show()

    
    })

})