
// user fields
var user = {
    name: "",
    username: "",
    password: "",
    email: "",
    birth: ""
  };

// users storage
  var users = [];

// default user
  var defaultUser = { name: "p", username: "p", password: "p", email: "p@gmail.com", birth: "16-03-1994" };

// insert default user to the storage
  users.push(defaultUser);