
$(document).ready(function(){
	$('#mainWindow').children().hide()
	$('#nav').show()
	$('#logo').show()
	$('#welcome').show()
	$('#footer').show()

$('#registerPage').click(function(){
	$('#mainWindow').children().hide()
	$('#nav').show()
	$('#logo').show()
	$('#register').show()
	$('#footer').show()

})

})