
$(document).ready(function(){
	$('#mainWindow').children().hide()
	$('#nav').show()
	$('#logo').show()
	$('#welcome').show()
	$('#footer').show()

$('#RegisterBtn').click(function(){
	$('#mainWindow').children().hide()
	$('#nav').show()
	$('#logo').show()
	$('#register').show()
	$('#footer').show()

})

})